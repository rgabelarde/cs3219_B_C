const jokes = [
    {
        id: 1,
        title: "Grape Wine",
        joke: "What did the grape say when it was stepped on? Nothing, it just let out a little wine",
        author: "Sean Grey",
    },
    {
        id: 2,
        title: "Plateaus are flat",
        joke: "A plateau is the highest form of flattery.",
        author: "John Doe'",
    },
    {
        id: 3,
        title: "Fresh Prince of Bel-Air",
        joke: "How do you find Will Smith in the snow? Look for fresh prints.",
        author: "Janet Dane'",
    },
];
export default jokes;